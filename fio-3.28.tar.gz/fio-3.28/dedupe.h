#ifndef DEDUPE_H
#define DEDUPE_H

int init_dedupe_working_set_seeds(struct thread_data *td);

#endif
